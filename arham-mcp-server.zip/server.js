
const express = require('express');
const app = express();
app.use(express.json());

app.post('/sse', (req, res) => {
  const userMessage = req.body.message;

  let reply = "Let me get back to you with that.";
  if (userMessage.includes("₹40K")) {
    reply = "₹40K plan includes 3 reels/week, 1 ad campaign & influencer push.";
  }

  res.json({ reply });
});

app.get('/', (req, res) => {
  res.send("Arham MCP Server is live.");
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
